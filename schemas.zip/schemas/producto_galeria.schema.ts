import { Schema } from 'mongoose';

export const Producto_galeriaSchema = new Schema({
  titulo: {
    type: String,
    require: true,
    trim: true,
  },
  imagen: { type: String, require: true, trim: true },
  producto: { type: Schema.Types.ObjectId, ref: 'Producto' },
  tenant: {
    type: Schema.Types.ObjectId,
    ref: 'Tenant',
    require: true,
  },
  createdAT: { type: Date, default: Date.now }
});
