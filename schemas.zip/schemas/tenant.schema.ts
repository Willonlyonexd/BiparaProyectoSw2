import { Schema } from 'mongoose';

export const TenantSchema = new Schema({
  nombreTienda: {
    type: String,
    required: true,
    trim: true,
  },
  suscripcion: {
    type: String,
    required: true,
    trim: true,
  },
  estado: {
    type: Boolean,
    default: true,
    required: true,
  },
  subdominio: {
    type: String,
    required: true,
    trim: true,
  },
  createdAT: { type: Date, default: Date.now },
});