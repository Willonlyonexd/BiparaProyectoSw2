import { Schema } from 'mongoose';

export const TenantSchema = new Schema({
  nombreTienda: {
    type: String,
    required: true,
    trim: true,
  },
  tenant: {
    type: Schema.Types.ObjectId,
    ref: 'Tenant',
    require: true,
  },
  tipo:{
    type: Number,
    required: true,
    trim: true,
  }
});